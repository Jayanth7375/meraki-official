import Staff from "../models/Staff.js";

// CREATE
export const createStaff = async (req, res) => {
  try {
    const staff = await Staff.create(req.body);
    res.status(201).json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// READ ALL
export const getStaffs = async (req, res) => {
  try {
    const staffs = await Staff.find()
      .populate("departmentId", "name")
      .sort({ createdAt: -1 });

    res.json(staffs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// UPDATE
export const updateStaff = async (req, res) => {
  try {
    const { id } = req.params;
    const staff = await Staff.findByIdAndUpdate(id, req.body, { new: true });
    res.json(staff);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE
export const deleteStaff = async (req, res) => {
  try {
    const { id } = req.params;
    await Staff.findByIdAndDelete(id);
    res.json({ message: "Staff deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
