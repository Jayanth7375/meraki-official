import "./Auth.css";
import logo from "../assets/image.png";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function ForgotPassword() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState(1); // ✅ 1 = email, 2 = otp
  const [error, setError] = useState("");

  // ✅ Email Regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // ✅ Handle Send OTP
  const handleSendOtp = (e) => {
    e.preventDefault();

    if (!emailRegex.test(email)) {
      setError("Enter a valid email address");
      return;
    }

    setError("");
    setStep(2); // ✅ move to OTP screen
  };

  // ✅ Handle Verify OTP
  const handleVerifyOtp = (e) => {
    e.preventDefault();

    if (otp.length !== 6) {
      setError("Enter valid 6-digit OTP");
      return;
    }

    setError("");
    alert("Password reset successful!");
    navigate("/login"); // ✅ back to login
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <img src={logo} alt="College Logo" className="auth-logo" />

        {step === 1 && (
          <>
            <h2>Reset Password</h2>

            <input
              type="email"
              placeholder="Enter your email"
              className="auth-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button className="auth-btn" onClick={handleSendOtp}>
              Send OTP
            </button>

            <p className="auth-link">
              Back to{" "}
              <span onClick={() => navigate("/login")}>Login</span>
            </p>
          </>
        )}

        {step === 2 && (
          <>
            <h2>Enter OTP</h2>

            <input
              type="text"
              placeholder="Enter 6-digit OTP"
              className="auth-input"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              maxLength={6}
            />

            {error && <p style={{ color: "red" }}>{error}</p>}

            <button className="auth-btn" onClick={handleVerifyOtp}>
              Verify OTP
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export default ForgotPassword;
