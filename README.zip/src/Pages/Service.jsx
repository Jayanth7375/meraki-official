import "./Service.css";
import heroImg from "../assets/hero-service.webp"; // ✅ use a neutral stock image
import { useNavigate } from "react-router-dom";

function Services() {
  const navigate = useNavigate();

  return (
    <div className="services-page">
      {/* ================= HERO ================= */}
      <section className="services-hero">
        <img src={heroImg} alt="Our Services" />
        <div className="services-overlay">
          <h1>Our Services</h1>
          <p>Powering Your Education With Excellence</p>

          
        </div>
      </section>

      {/* ================= INTRO ================= */}
      <section className="services-intro">
        <h2>What We Offer</h2>
        <p>
          At Meraki College of Innovation, we provide a complete ecosystem of
          academic excellence, professional growth, innovation, and student
          wellbeing. Our services are designed to ensure success from classroom
          to career.
        </p>
      </section>

      {/* ================= SERVICES GRID ================= */}
      <section className="services-grid-section">
        <div className="services-grid">
          <div className="service-card">
            🎓 <h4>Academic Programs</h4>
            <p>B.Tech, MBA, AI, Data Science, Cyber Security & more.</p>
          </div>

          <div className="service-card">
            💼 <h4>Career Guidance</h4>
            <p>Dedicated career counselors, resume training, mock interviews.</p>
          </div>

          <div className="service-card">
            🧪 <h4>Research Facilities</h4>
            <p>Advanced research labs, funded projects, innovation grants.</p>
          </div>

          <div className="service-card">
            📚 <h4>Digital Library</h4>
            <p>24/7 digital access to journals, books, and research papers.</p>
          </div>

          <div className="service-card">
            🏠 <h4>Hostel Facilities</h4>
            <p>Separate hostels with security, Wi-Fi, food & medical support.</p>
          </div>

          <div className="service-card">
            ⚽ <h4>Sports & Fitness</h4>
            <p>Indoor & outdoor sports, gym, yoga & wellness programs.</p>
          </div>

          <div className="service-card">
            💻 <h4>Smart Classrooms</h4>
            <p>AI-enabled teaching, virtual labs, smart boards & AR tools.</p>
          </div>

          <div className="service-card">
            🌍 <h4>Global Exposure</h4>
            <p>International programs, student exchange & global internships.</p>
          </div>

          <div className="service-card">
            🏥 <h4>Health & Wellness</h4>
            <p>On-campus hospital, mental health support & fitness care.</p>
          </div>

          <div className="service-card">
            🚀 <h4>Startup & Incubation</h4>
            <p>Entrepreneur support, funding guidance & product incubation.</p>
          </div>

          <div className="service-card">
            🏅 <h4>Clubs & Communities</h4>
            <p>Technical clubs, cultural clubs, leadership boards.</p>
          </div>

          <div className="service-card">
            🧠 <h4>Skill Development</h4>
            <p>Soft skills, communication, leadership & corporate readiness.</p>
          </div>
        </div>
      </section>

      {/* ================= EXTRA VALUE ================= */}
      <section className="services-extra">
        <h2>Why Students Choose Our Services</h2>
        <p>
          ✔ Industry-linked learning  
          ✔ Global certifications  
          ✔ Internship & placement guarantee  
          ✔ Innovation-focused education  
          ✔ 360° student development
        </p>
      </section>

      {/* ================= CTA ================= */}
      <section className="services-cta">
        <h2>Build Your Future With Us</h2>
        <p>Admissions Open for 2025 — Apply Today</p>
        <button onClick={() => navigate("/login")}>Apply Now</button>
      </section>
    </div>
  );
}

export default Services;
