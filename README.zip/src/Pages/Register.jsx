import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/image.png";
import "./Auth.css";

function Register() {
  const [role, setRole] = useState("student"); // ✅ ROLE STATE

  const [form, setForm] = useState({
    fname: "",
    lname: "",
    email: "",
    phone: "",
    password: "",
    confirm: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const regex = {
    fname: /^[A-Za-z ]{3,}$/,
    lname: /^[A-Za-z ]{1,}$/,
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    phone: /^[6-9][0-9]{9}$/,
    password: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/,
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    if (name === "confirm") {
      if (value !== form.password) {
        setErrors({ ...errors, confirm: "Passwords do not match" });
      } else {
        setErrors({ ...errors, confirm: "" });
      }
      return;
    }

    if (!regex[name].test(value)) {
      setErrors({ ...errors, [name]: "Invalid " + name });
    } else {
      setErrors({ ...errors, [name]: "" });
    }
  };

const handleSubmit = (e) => {
  e.preventDefault();

  if (Object.values(form).some((v) => v === "")) {
    alert("Please fill all fields");
    return;
  }

  if (Object.values(errors).some((err) => err)) {
    alert("Please fix all errors");
    return;
  }

  // 🔥 ADMIN EMAIL VALIDATION
  if (role === "admin" && form.email !== "admin@mcoi.ac.in") {
    alert("❌ Only official admin email is allowed: admin@mcoi.ac.in");
    return;
  }

  // SAVE USER IN LOCAL STORAGE
  const users = JSON.parse(localStorage.getItem("users") || "[]");

  users.push({
    ...form,
    role,
  });

  localStorage.setItem("users", JSON.stringify(users));

  alert(`✅ Registered as ${role.toUpperCase()}`);
  navigate("/login");
};


  return (
    <div className="auth-page">
      <div className="auth-card">

        <img src={logo} alt="College Logo" className="auth-logo" />

        <h2 className="auth-title">Create Account</h2>
        <p className="auth-subtitle">Register to apply for Meraki programs</p>

        {/* ✅ PREMIUM ROLE SELECTOR */}
        <div className="role-switch">
        <button
          className={role === "student" ? "role-btn active" : "role-btn"}
          onClick={() => setRole("student")}
          type="button"
        >
          Student
        </button>

        <button
          className={role === "admin" ? "role-btn active" : "role-btn"}
          onClick={() => setRole("admin")}
          type="button"
        >
          Admin
        </button>
      </div>


        <form onSubmit={handleSubmit}>

          <div className="auth-field">
            <label>First Name</label>
            <input
              type="text"
              name="fname"
              value={form.fname}
              onChange={handleChange}
              placeholder="John"
            />
            {errors.fname && <span className="auth-error">{errors.fname}</span>}
          </div>

          <div className="auth-field">
            <label>Last Name</label>
            <input
              type="text"
              name="lname"
              value={form.lname}
              onChange={handleChange}
              placeholder="Doe"
            />
            {errors.lname && <span className="auth-error">{errors.lname}</span>}
          </div>

          <div className="auth-field">
            <label>Email</label>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="you@example.com"
            />
            {errors.email && <span className="auth-error">{errors.email}</span>}
          </div>

          <div className="auth-field">
            <label>Phone</label>
            <input
              type="tel"
              name="phone"
              value={form.phone}
              onChange={handleChange}
              placeholder="9876543210"
            />
            {errors.phone && <span className="auth-error">{errors.phone}</span>}
          </div>

          <div className="auth-field">
            <label>Password</label>
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="Min 6 chars, 1 number"
            />
            {errors.password && <span className="auth-error">{errors.password}</span>}
          </div>

          <div className="auth-field">
            <label>Confirm Password</label>
            <input
              type="password"
              name="confirm"
              value={form.confirm}
              onChange={handleChange}
              placeholder="Re-enter password"
            />
            {errors.confirm && <span className="auth-error">{errors.confirm}</span>}
          </div>

          <button type="submit" className="auth-btn">
            Register as {role}
          </button>

        </form>

        <p className="auth-secondary">
          Already have an account?{" "}
          <Link to="/login" className="auth-link">
            Login
          </Link>
        </p>

      </div>
    </div>
  );
}

export default Register;
