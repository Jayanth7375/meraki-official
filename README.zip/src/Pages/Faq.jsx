import { useState } from "react";
import "./Faq.css";
import { Link } from "react-router-dom";


const faqData = [
  {
    category: "Admissions",
    items: [
      {
        q: "What are the admission requirements?",
        a: "You must complete 10+2 with minimum 60%. Some programs require entrance exams and interviews."
      },
      {
        q: "When does the admission process start?",
        a: "Admissions usually begin in March every year for the August intake."
      },
      {
        q: "Do you offer scholarships?",
        a: "Yes, we offer merit-based and need-based scholarships."
      }
    ]
  },
  {
    category: "Academics",
    items: [
      {
        q: "What programs are offered?",
        a: "Engineering, Management, Computer Science, Arts & Sciences."
      },
      {
        q: "What is the student-faculty ratio?",
        a: "We maintain a 15:1 student-faculty ratio."
      }
    ]
  },
  {
    category: "Campus Life",
    items: [
      {
        q: "Is hostel facility available?",
        a: "Yes, separate hostels for boys and girls with 24/7 security."
      },
      {
        q: "Are sports facilities available?",
        a: "Yes, gym, playgrounds, indoor games and tournaments."
      }
    ]
  },
  {
    category: "Placements",
    items: [
      {
        q: "What is the placement rate?",
        a: "95% placement with 200+ hiring companies."
      },
      {
        q: "Does the college provide internship support?",
        a: "Yes, internships are mandatory with industry tie-ups."
      }
    ]
  }
];

function Faq() {
  const [active, setActive] = useState(null);
  const [search, setSearch] = useState("");

  const toggleFaq = (i) => {
    setActive(active === i ? null : i);
  };

  return (
    <>
      {/* HERO */}
      <section className="faq-hero">
        <div className="faq-overlay">
          <h1>Frequently Asked Questions</h1>
          <p>Everything you need to know about Meraki College</p>
        </div>
      </section>

      {/* SEARCH */}
      <section className="faq-search">
        <input
          type="text"
          placeholder="Search your question..."
          onChange={(e) => setSearch(e.target.value.toLowerCase())}
        />
      </section>

      {/* FAQ SECTION */}
      <section className="faq-section">
        {faqData.map((block, blockIndex) => (
          <div className="faq-category" key={blockIndex}>
            <h2>{block.category}</h2>

            {block.items
              .filter((item) =>
                item.q.toLowerCase().includes(search)
              )
              .map((item, index) => {
                const id = `${blockIndex}-${index}`;
                return (
                  <div
                    className={`faq-item ${active === id ? "open" : ""}`}
                    key={id}
                    onClick={() => toggleFaq(id)}
                  >
                    <div className="faq-question">
                      <h4>{item.q}</h4>
                      <span>{active === id ? "-" : "+"}</span>
                    </div>
                    <div className="faq-answer">
                      <p>{item.a}</p>
                    </div>
                  </div>
                );
              })}
          </div>
        ))}
      </section>

      {/* CTA */}
      <section className="faq-cta">
        <h2>Still Have Questions?</h2>
        <p>Our team is ready to help you anytime.</p>
        <Link to="/contact">
            <button>Contact Now</button>
        </Link>

      </section>
    </>
  );
}

export default Faq;
