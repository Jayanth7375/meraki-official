import "./Terms.css";

function Terms() {
  return (
    <section className="legal-page">
      <div className="legal-hero">
        <h1>Terms & Conditions</h1>
        <p>Last Updated: 2025</p>
      </div>

      <div className="legal-container">
        <h2>1. Acceptance of Terms</h2>
        <p>
          By accessing Meraki College of Innovation, you agree to follow all
          terms, policies, and rules stated on this website.
        </p>

        <h2>2. Admission Policy</h2>
        <p>
          Admission is based on merit and eligibility. Submission of application
          does not guarantee selection.
        </p>

        <h2>3. Fees & Payments</h2>
        <p>
          Fees once paid are non-refundable except in special conditions approved
          by the administration.
        </p>

        <h2>4. Student Responsibility</h2>
        <p>
          Students must maintain discipline, academic integrity, and respect all
          institutional guidelines.
        </p>

        <h2>5. Usage of Website</h2>
        <p>
          Any misuse, hacking attempt, or illegal activity will result in legal
          action.
        </p>

        <h2>6. Modifications</h2>
        <p>
          The institution reserves rights to change terms without prior notice.
        </p>
      </div>
    </section>
  );
}

export default Terms;
