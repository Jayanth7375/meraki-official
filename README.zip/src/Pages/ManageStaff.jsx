import { useEffect, useState } from "react";
import axios from "axios";
import AdminLayout from "../Components/AdminLayout";
import "./Admin.css";

export default function ManageStaff() {
  const [staffs, setStaffs] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [form, setForm] = useState({
    name: "",
    role: "",
    departmentId: "",
    email: "",
    phone: ""
  });
  const [editId, setEditId] = useState(null);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchStaffs();
    fetchDepartments();
  }, []);

  const fetchStaffs = async () => {
    const res = await axios.get("http://localhost:5000/api/staffs", {
      headers: { Authorization: `Bearer ${token}` }
    });
    setStaffs(res.data);
  };

  const fetchDepartments = async () => {
    const res = await axios.get("http://localhost:5000/api/departments");
    setDepartments(res.data);
  };

  const handleSubmit = async () => {
    if (!form.name || !form.role || !form.departmentId) {
      return alert("Fill required fields");
    }

    if (editId) {
      await axios.put(
        `http://localhost:5000/api/staffs/${editId}`,
        form,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setEditId(null);
    } else {
      await axios.post(
        "http://localhost:5000/api/staffs",
        form,
        { headers: { Authorization: `Bearer ${token}` } }
      );
    }

    setForm({ name: "", role: "", departmentId: "", email: "", phone: "" });
    fetchStaffs();
  };

  const handleEdit = (s) => {
    setForm({
      name: s.name,
      role: s.role,
      departmentId: s.departmentId._id,
      email: s.email,
      phone: s.phone
    });
    setEditId(s._id);
  };

  const handleDelete = async (id) => {
    await axios.delete(
      `http://localhost:5000/api/staffs/${id}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    fetchStaffs();
  };

  return (
    <AdminLayout>
      <h1 className="admin-title">Manage Staff</h1>

      <div className="admin-card">
        <h2>Add / Edit Staff</h2>

        <input className="admin-input" placeholder="Name"
          value={form.name}
          onChange={e => setForm({ ...form, name: e.target.value })}
        />

        <input className="admin-input" placeholder="Role"
          value={form.role}
          onChange={e => setForm({ ...form, role: e.target.value })}
        />

        <select className="admin-input"
          value={form.departmentId}
          onChange={e => setForm({ ...form, departmentId: e.target.value })}
        >
          <option value="">Select Department</option>
          {departments.map(d => (
            <option key={d._id} value={d._id}>{d.name}</option>
          ))}
        </select>

        <input className="admin-input" placeholder="Email"
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
        />

        <input className="admin-input" placeholder="Phone"
          value={form.phone}
          onChange={e => setForm({ ...form, phone: e.target.value })}
        />

        <button className="admin-btn" onClick={handleSubmit}>
          {editId ? "Update Staff" : "Add Staff"}
        </button>
      </div>

      <div className="admin-card">
        <h2>Staff List</h2>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Role</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {staffs.map(s => (
              <tr key={s._id}>
                <td>{s.name}</td>
                <td>{s.role}</td>
                <td>{s.departmentId?.name}</td>
                <td>
                  <button className="edit-btn" onClick={() => handleEdit(s)}>Edit</button>
                  <button className="delete-btn" onClick={() => handleDelete(s._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
