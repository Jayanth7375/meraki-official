import { useEffect, useState } from "react";
import axios from "axios";
import AdminLayout from "../Components/AdminLayout";
import "./Admin.css";

export default function ManageDepartments() {
  const [departments, setDepartments] = useState([]);
  const [dept, setDept] = useState("");
  const [editId, setEditId] = useState(null);

  const token = localStorage.getItem("token");

  // 🔹 FETCH FROM BACKEND
  useEffect(() => {
    fetchDepartments();
  }, []);

  const fetchDepartments = async () => {
    try {
      const res = await axios.get(
        "http://localhost:5000/api/departments"
      );
      setDepartments(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // 🔹 ADD / UPDATE
  const handleAdd = async () => {
    if (!dept) return alert("Enter department");

    try {
      if (editId) {
        // UPDATE
        await axios.put(
          `http://localhost:5000/api/departments/${editId}`,
          { name: dept, description: dept },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        addActivity(`Updated Department: ${dept}`);
        setEditId(null);
      } else {
        // CREATE
        await axios.post(
          "http://localhost:5000/api/departments",
          { name: dept, description: dept },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        addActivity(`Added Department: ${dept}`);
      }

      setDept("");
      fetchDepartments(); // refresh list
    } catch (err) {
      alert(err.response?.data?.message || "Action failed");
    }
  };

  // 🔹 DELETE
  const handleDelete = async (id) => {
    try {
      await axios.delete(
        `http://localhost:5000/api/departments/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      addActivity("Deleted Department");
      fetchDepartments();
    } catch (err) {
      alert("Delete failed");
    }
  };

  // 🔹 EDIT
  const handleEdit = (d) => {
    setDept(d.name);
    setEditId(d._id);
  };

  // 🔹 ACTIVITY LOG (UNCHANGED)
  function addActivity(msg) {
    const logs = JSON.parse(localStorage.getItem("activities")) || [];
    const newLog = `${new Date().toLocaleTimeString()} - ${msg}`;
    logs.push(newLog);

    localStorage.setItem("activities", JSON.stringify(logs));
    window.dispatchEvent(new Event("storageUpdate"));
  }

  return (
    <AdminLayout>
      <h1 className="admin-title">Manage Departments</h1>

      <div className="admin-card">
        <h2>Add / Edit Department</h2>
        <div className="input-row">
          <input
            className="admin-input"
            placeholder="Department Name"
            value={dept}
            onChange={(e) => setDept(e.target.value)}
          />
          <button className="admin-btn" onClick={handleAdd}>
            {editId ? "Update Department" : "Add Department"}
          </button>
        </div>
      </div>

      <div className="admin-card">
        <h2>Department List</h2>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {departments.map((d) => (
              <tr key={d._id}>
                <td>{d.name}</td>
                <td>
                  <button className="edit-btn" onClick={() => handleEdit(d)}>
                    Edit
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(d._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
