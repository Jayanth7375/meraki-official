import { useEffect, useState } from "react";
import AdminLayout from "../Components/AdminLayout";
import "./Admin.css";

export default function AdminDashboard() {
  const [staffCount, setStaffCount] = useState(0);
  const [courseCount, setCourseCount] = useState(0);
  const [deptCount, setDeptCount] = useState(0);
  const [students] = useState(240);
  const [activities, setActivities] = useState([]);

  function loadData() {
    const staff = JSON.parse(localStorage.getItem("staff")) || [];
    const courses = JSON.parse(localStorage.getItem("courses")) || [];
    const depts = JSON.parse(localStorage.getItem("departments")) || [];
    const logs = JSON.parse(localStorage.getItem("activities")) || [];

    setStaffCount(staff.length);
    setCourseCount(courses.length);
    setDeptCount(depts.length);
    setActivities(logs.slice().reverse());
  }

  useEffect(() => {
    loadData();

    window.addEventListener("storageUpdate", loadData);

    return () => window.removeEventListener("storageUpdate", loadData);
  }, []);

  return (
    <AdminLayout>
      <div className="dashboard-wrapper">
        <h1 className="dash-title">Admin Dashboard</h1>

        <div className="stats-row">
          <div className="stat-box"><h3>Staff</h3><p>{staffCount}</p></div>
          <div className="stat-box"><h3>Courses</h3><p>{courseCount}</p></div>
          <div className="stat-box"><h3>Departments</h3><p>{deptCount}</p></div>
          <div className="stat-box"><h3>Students</h3><p>{students}</p></div>
        </div>

        {/* ✅ LIVE ACTIVITY */}
        <div className="section">
          <h2>📝 Recent Activities</h2>
          <div className="activity-box">
            {activities.length === 0 ? (
              <p>No activity yet.</p>
            ) : (
              activities.map((a, i) => <p key={i}>• {a}</p>)
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
