import "./Privacy.css";

function Privacy() {
  return (
    <section className="legal-page">
      <div className="legal-hero">
        <h1>Privacy Policy</h1>
        <p>Your Trust Matters To Us</p>
      </div>

      <div className="legal-container">
        <h2>Information We Collect</h2>
        <p>
          We collect personal information such as name, email, phone number when
          you submit forms.
        </p>

        <h2>How We Use It</h2>
        <p>
          Your data is used strictly for academic communication and admission
          processes.
        </p>

        <h2>Data Security</h2>
        <p>
          We implement strict security measures to protect your personal
          information.
        </p>

        <h2>Cookies</h2>
        <p>
          Our website may use cookies to enhance browsing experience.
        </p>

        <h2>Your Rights</h2>
        <p>
          You may request data deletion by contacting the administration.
        </p>
      </div>
    </section>
  );
}

export default Privacy;
