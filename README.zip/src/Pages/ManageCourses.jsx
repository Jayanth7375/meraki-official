import { useEffect, useState } from "react";
import axios from "axios";
import AdminLayout from "../Components/AdminLayout";
import "./Admin.css";

export default function ManageCourses() {
  const [courses, setCourses] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [course, setCourse] = useState("");
  const [deptId, setDeptId] = useState("");
  const [editId, setEditId] = useState(null);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchCourses();
    fetchDepartments();
  }, []);

  const fetchCourses = async () => {
    const res = await axios.get("http://localhost:5000/api/courses");
    setCourses(res.data);
  };

  const fetchDepartments = async () => {
    const res = await axios.get("http://localhost:5000/api/departments");
    setDepartments(res.data);
  };

  const handleAdd = async () => {
    if (!course || !deptId) return alert("Fill all fields");

    if (editId) {
      await axios.put(
        `http://localhost:5000/api/courses/${editId}`,
        { name: course, departmentId: deptId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      addActivity(`Updated Course: ${course}`);
      setEditId(null);
    } else {
      await axios.post(
        "http://localhost:5000/api/courses",
        { name: course, departmentId: deptId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      addActivity(`Added Course: ${course}`);
    }

    setCourse("");
    setDeptId("");
    fetchCourses();
  };

  const handleEdit = (c) => {
    setCourse(c.name);
    setDeptId(c.departmentId._id);
    setEditId(c._id);
  };

  const handleDelete = async (id) => {
    await axios.delete(
      `http://localhost:5000/api/courses/${id}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    addActivity("Deleted Course");
    fetchCourses();
  };

  function addActivity(msg) {
    const logs = JSON.parse(localStorage.getItem("activities")) || [];
    logs.push(`${new Date().toLocaleTimeString()} - ${msg}`);
    localStorage.setItem("activities", JSON.stringify(logs));
    window.dispatchEvent(new Event("storageUpdate"));
  }

  return (
    <AdminLayout>
      <h1 className="admin-title">Manage Courses</h1>

      <div className="admin-card">
        <h2>Add / Edit Course</h2>
        <div className="input-row">
          <input
            className="admin-input"
            placeholder="Course Name"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
          />

          <select
            className="admin-input"
            value={deptId}
            onChange={(e) => setDeptId(e.target.value)}
          >
            <option value="">Select Department</option>
            {departments.map((d) => (
              <option key={d._id} value={d._id}>
                {d.name}
              </option>
            ))}
          </select>

          <button className="admin-btn" onClick={handleAdd}>
            {editId ? "Update Course" : "Add Course"}
          </button>
        </div>
      </div>

      <div className="admin-card">
        <h2>Course List</h2>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Course</th>
              <th>Department</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {courses.map((c) => (
              <tr key={c._id}>
                <td>{c.name}</td>
                <td>{c.departmentId?.name}</td>
                <td>
                  <button className="edit-btn" onClick={() => handleEdit(c)}>
                    Edit
                  </button>
                  <button
                    className="delete-btn"
                    onClick={() => handleDelete(c._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AdminLayout>
  );
}
